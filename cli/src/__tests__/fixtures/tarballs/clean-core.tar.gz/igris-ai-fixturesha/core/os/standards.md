---
layer: conduct
tier: boot
scope: universal
summary: Cross-actor baseline (fixture).
---
# Universal Standards (fixture)
