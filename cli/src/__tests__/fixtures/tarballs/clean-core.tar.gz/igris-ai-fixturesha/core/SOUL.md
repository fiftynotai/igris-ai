---
layer: identity
tier: boot
scope: orchestrator
summary: The OS persona (fixture).
---
# Igris Soul (fixture)
