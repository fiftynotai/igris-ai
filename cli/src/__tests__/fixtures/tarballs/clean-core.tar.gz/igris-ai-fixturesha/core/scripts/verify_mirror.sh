#!/usr/bin/env bash
echo "verify_mirror (fixture)"
